<?php
/**
 * @package Hello_Formstar
 * @version 1.7.2
 */
/*
 * Plugin Name:       Author Bio
 * Plugin URI:        https://www.fiverr.com/abdur_wp_expert/
 * Description:       Build responsive author box with social icons to any post or page with shortcode. Great Amazing author box! for any wordpress site!
 * Version:           1.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Abdur Rahim
 * Author URI:        https://www.fiverr.com/abdur_wp_expert
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://www.fiverr.com/abdur_wp_expert
 * Text Domain:       author-bio
 * Domain Path:       /languages
 */
/*
{Plugin Name} is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
any later version.
{Plugin Name} is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with {Plugin Name}. If not, see {URI to Plugin License}.
*/

if (!defined('ABSPATH')) {
  die('Hey, get out from here!');
}
if (is_admin()) {
  require_once('profile.php');
}

// Author function
include_once('includes/bio_file.php');

function formstar_css_js()
{
  wp_enqueue_style('formstar-css', plugins_url('assets/css/style.css', __FILE__));
}

add_action('wp_enqueue_scripts', 'formstar_css_js');