<?php
function formstar_user_bio($content)
{
  global $post;

  $author = get_user_by('id', $post->post_author);
  $bio = get_user_meta($author->ID, 'description', true);
  $twitter = get_user_meta($author->ID, 'twitter', true);
  $linkdin = get_user_meta($author->ID, 'linkdin', true);
  $facebook = get_user_meta($author->ID, 'facebook', true);
  ob_start();
?>
<div class="bio-main">
  <div class="img">
    <?php if (isset($author->ID)) {
    echo get_avatar($author->ID, 200);
  } elseif ($author->ID == "") { ?>
    <img src='<?php echo plugins_url("user.png", __FILE__); ?>'>
    <?php } ?>
  </div>
  <div class="bio-con">
    <div class="name">
      <h4 id="title"><?php echo $author->display_name; ?> </h4>
    </div>
    <div class="bio"><?php echo wpautop(wp_kses_post($bio)); ?></div>
  </div>
  <div class="so-link">
    <ul class="social">
      <!-- Twitter -->
      <?php if (isset($twitter)) { ?>
      <li><a href="<?php echo esc_url($twitter); ?>" class="tex-white fs-5">
          <?php _e('Twitter', 'author-bio'); ?>
        </a></li>
      <?php } ?>

      <!-- Facebook -->
      <?php if (isset($facebook)) { ?>
      <li><a href="<?php echo esc_url($facebook); ?>">
          <?php _e('Facebook', 'author-bio'); ?>
        </a></li>
      <?php } ?>

      <!-- Linkdin -->
      <?php if (isset($linkdin)) { ?>
      <li><a href="<?php echo esc_url($linkdin); ?>">
          <?php _e('Linkdin', 'author-bio'); ?>
        </a></li>
      <?php } ?>
    </ul>

  </div>
</div>
<?php
  $bio_cont = ob_get_clean();

  return $content . $bio_cont;
}

add_filter('the_content', 'formstar_user_bio');