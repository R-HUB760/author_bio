<?php

if(!defined('ABSPATH')){
  die('Hey, get out from here!');
}

function formstar_user_methods($methods){
  $methods['twitter'] = __('Twitter', 'author-bio');
  $methods['facebook'] = __('Facebook', 'author-bio');
  $methods['linkdin'] = __('Linkdin', 'author-bio');
  
  return $methods;
}
add_filter('user_contactmethods', 'formstar_user_methods');